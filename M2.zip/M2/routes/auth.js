const express = require('express');
const router = express.Router();
const passport = require('passport');

// Login page
router.get('/login', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Login - Sistema de Gestão</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          text-align: center; 
          padding: 50px;
          background-color: #f5f5f5;
        }
        .login-container {
          max-width: 400px;
          margin: 0 auto;
          padding: 30px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .btn {
          display: inline-block;
          padding: 12px 24px;
          background-color: #4285f4;
          color: white;
          text-decoration: none;
          border-radius: 4px;
          font-size: 16px;
          margin: 10px 0;
        }
        .btn:hover {
          background-color: #3367d6;
        }
      </style>
    </head>
    <body>
      <div class="login-container">
        <h1>🔐 Sistema de Gestão</h1>
        <p>Faça login para acessar o sistema</p>
        
        <a href="/auth/google" class="btn">
          🔑 Entrar com Google
        </a>
        
        <p style="margin-top: 30px; font-size: 12px; color: #666;">
          Administradores: authtutorial6@gmail.com<br>
          Clientes: Qualquer outra conta Google
        </p>
      </div>
    </body>
    </html>
  `);
});

// Google OAuth routes
router.get('/google', 
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

// ✅ CORREÇÃO PRINCIPAL: Callback simplificado que redireciona DIRETAMENTE
router.get('/google/callback', 
  passport.authenticate('google', { failureRedirect: '/auth/login?error=auth_failed' }),
  (req, res) => {
    try {
      console.log('✅ Google callback successful');
      
      if (!req.user || !req.user.token) {
        console.error('❌ No user or token in callback');
        return res.redirect('http://localhost:3000?error=no_token');
      }
      
      console.log('User:', req.user.nome, req.user.email);
      console.log('Admin:', req.user.isAdmin);
      console.log('Token generated successfully');
      
      // ✅ REDIRECIONAR DIRETAMENTE SEM PÁGINA INTERMEDIÁRIA
      const token = req.user.token;
      const redirectUrl = `http://localhost:3000?token=${encodeURIComponent(token)}`;
      console.log('🔄 Redirecting directly to:', redirectUrl);
      
      res.redirect(redirectUrl);
      
    } catch (error) {
      console.error('❌ Error in Google callback:', error);
      res.redirect('http://localhost:3000?error=callback_failed');
    }
  }
);

// Logout route
router.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      return res.status(500).json({ error: 'Logout failed' });
    }
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: 'Session destruction failed' });
      }
      res.redirect('http://localhost:3000');
    });
  });
});

module.exports = router;