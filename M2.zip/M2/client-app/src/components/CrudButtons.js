import React from 'react';

function CrudButtons({ onGet, onPost }) {
  return (
    <div className="crud-buttons">
      <button onClick={onGet} className="crud-button get">GET</button>
      <button onClick={onPost} className="crud-button post">POST</button>
    </div>
  );
}

export default CrudButtons;