import React, { useEffect, useState } from 'react';
import './App.css';
import CrudButtons from './components/CrudButtons';

function App() {
  const [data, setData] = useState({
    utilizadores: [],
    administradores: [],
    categorias: [],
    produtos: [],
    pedidos: [],
    itenspedido: [],
    pagamentos: []
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // ✅ NOVO: Estados de autenticação
  const [authToken, setAuthToken] = useState(localStorage.getItem('jwt_token'));
  const [user, setUser] = useState(null);

  const API_URL = 'http://localhost:3001/api';

  // ✅ CORRIGIR: Verificar token ao carregar (mais robusto)
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const error = urlParams.get('error');
    
    console.log('🔍 Checking URL params:', { token: !!token, error });
    
    if (error) {
      console.error('❌ Authentication error:', error);
      alert(`❌ Erro de autenticação: ${error}`);
      // Clean URL
      window.history.replaceState({}, document.title, window.location.pathname);
      return;
    }
    
    if (token) {
      console.log('✅ Token received from URL');
      localStorage.setItem('jwt_token', token);
      setAuthToken(token);
      
      // Decode JWT to get user info
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setUser(payload);
        console.log('✅ User authenticated:', payload);
        
        // Test token validity immediately
        testTokenValidity(token);
        
      } catch (e) {
        console.error('❌ Error decoding JWT:', e);
        alert('❌ Token inválido recebido');
        localStorage.removeItem('jwt_token');
        setAuthToken(null);
      }
      
      // Clean URL
      window.history.replaceState({}, document.title, window.location.pathname);
    } else {
      // Check if there's a stored token
      const storedToken = localStorage.getItem('jwt_token');
      if (storedToken) {
        console.log('🔄 Checking stored token...');
        try {
          const payload = JSON.parse(atob(storedToken.split('.')[1]));
          // Check if token is expired
          if (payload.exp * 1000 > Date.now()) {
            setUser(payload);
            setAuthToken(storedToken);
            console.log('✅ Using stored token for:', payload.email);
          } else {
            console.log('⚠️ Stored token expired');
            localStorage.removeItem('jwt_token');
            setAuthToken(null);
          }
        } catch (e) {
          console.error('❌ Error with stored token:', e);
          localStorage.removeItem('jwt_token');
          setAuthToken(null);
        }
      }
    }
  }, []);

  // ✅ NOVO: Testar validade do token
  const testTokenValidity = async (token) => {
    try {
      console.log('🔬 Testing token validity...');
      const response = await fetch(`${API_URL}/utilizadores`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        console.log('✅ Token is valid and working');
      } else if (response.status === 401) {
        console.log('❌ Token is invalid or expired');
        handleLogout();
      } else if (response.status === 403) {
        console.log('⚠️ Token valid but insufficient permissions (normal for some operations)');
      }
    } catch (error) {
      console.error('❌ Error testing token:', error);
    }
  };

  // ✅ NOVO: Funções de autenticação
  const handleGoogleLogin = () => {
    window.location.href = 'http://localhost:3001/auth/google';
  };

  const handleLogout = () => {
    localStorage.removeItem('jwt_token');
    setAuthToken(null);
    setUser(null);
    window.location.href = 'http://localhost:3001/auth/logout';
  };

  // ✅ MODIFICADO: handleCrud com JWT
  const handleCrud = async (method, endpoint, id = null) => {
    // ⚠️ IMPORTANTE: Verificar autenticação ANTES de qualquer operação
    if (!authToken) {
      alert('❌ Você precisa fazer login primeiro!');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const url = id ? `${API_URL}/${endpoint}/${id}` : `${API_URL}/${endpoint}`;
      let requestOptions = {
        method: method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}` // ✅ ADICIONAR JWT TOKEN
        }
      };

      if (method === 'POST' || method === 'PUT') {
        switch(endpoint) {
          case 'utilizadores':
            requestOptions.body = JSON.stringify({
              nome: method === 'POST' ? 'Novo Utilizador' : 'Utilizador Atualizado',
              email: method === 'POST' ? `novo${Date.now()}@email.com` : `atualizado${Date.now()}@email.com`,
              senha: '123456',
              endereco: method === 'POST' ? 'Rua Nova, 123' : 'Rua Atualizada, 456',
              telefone: method === 'POST' ? '123456789' : '987654321',
              tipo_utilizador: 'cliente'
            });
            break;

          case 'administradores':
            requestOptions.body = JSON.stringify({
              id_utilizador: method === 'POST' ? 1 : id,
              api_key: method === 'POST' ? 'nova_api_key' : 'api_key_atualizada'
            });
            break;

          case 'categorias':
            requestOptions.body = JSON.stringify({
              nome: method === 'POST' ? 'Nova Categoria' : 'Categoria Atualizada'
            });
            break;

          case 'produtos':
            requestOptions.body = JSON.stringify({
              nome: method === 'POST' ? 'Novo Produto' : 'Produto Atualizado',
              descricao: method === 'POST' ? 'Nova Descrição' : 'Descrição Atualizada',
              preco: method === 'POST' ? 99.99 : 149.99,
              stock: method === 'POST' ? 10 : 20,
              categoria_id: 1
            });
            break;

          case 'pedidos':
            requestOptions.body = JSON.stringify({
              id_utilizador: 1,
              data_pedido: new Date().toISOString(),
              estado_pagamento: method === 'POST' ? 'Pendente' : 'Concluído'
            });
            break;

          case 'itenspedido': 
    requestOptions.body = JSON.stringify({
      id_pedido: 2,  // ✅ Mudou de 1 para 2
      id_produto: 2, // ✅ Mudou de 1 para 2
      quantidade: method === 'POST' ? 2 : 5,
      preco_unitario: method === 'POST' ? 25.50 : 30.75
    });
    break;

          case 'pagamentos':
            requestOptions.body = JSON.stringify({
              id_pedido: 1,
              valor: method === 'POST' ? 99.99 : 149.99,
              estado_pagamento: method === 'POST' ? 'Pendente' : 'Aprovado',
              metodo_pagamento: method === 'POST' ? 'Cartão' : 'PIX'
            });
            break;

          default:
            break;
        }
      }

      const response = await fetch(url, requestOptions);

      // ✅ NOVO: Tratamento de erros de autenticação
      if (!response.ok) {
        if (response.status === 401) {
          alert('❌ Token expirado! Faça login novamente.');
          handleLogout();
          return;
        }
        if (response.status === 403) {
          alert('❌ Acesso negado! Apenas administradores podem realizar esta operação.');
          return;
        }
        
        const errorText = await response.text();
        let errorMessage;
        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || `HTTP error! status: ${response.status}`;
        } catch (e) {
          errorMessage = errorText || `HTTP error! status: ${response.status}`;
        }
        throw new Error(errorMessage);
      }

      // Só tenta fazer parse se houver conteúdo
      let result = null;
      if (response.status !== 204) {
        result = await response.json();
      }

      // Atualiza os dados após a operação
      const getResponse = await fetch(`${API_URL}/${endpoint}`, {
        headers: {
          'Authorization': `Bearer ${authToken}` // ✅ JWT também no GET
        }
      });
      if (!getResponse.ok) throw new Error(`Error fetching updated data: ${getResponse.status}`);
      const updated = await getResponse.json();

      setData(prev => ({
        ...prev,
        [endpoint]: updated
      }));

      console.log(`${method} operation successful`);
    } catch (error) {
      console.error('Error:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  // ====== VALIDAÇÕES =======
const validateDelete = (endpoint, item) => {
  switch(endpoint) {
    case 'categorias':
      return window.confirm(
        `⚠️ ATENÇÃO!\n\n` +
        `Ao apagar a categoria "${item.nome}", todos os produtos desta categoria ` +
        `ficarão SEM categoria (categoria_id = NULL).\n\n` +
        `Tens a certeza que queres continuar?`
      );
    
    case 'produtos':
      // Verificar se tem itens_pedido (esta verificação será básica por agora)
      const hasOrders = data.itenspedido.some(item_pedido => item_pedido.id_produto === item.id);
      
      if (hasOrders) {
        return window.confirm(
          `⚠️ CUIDADO!\n\n` +
          `O produto "${item.nome}" tem pedidos associados!\n` +
          `Ao apagar este produto, poderão ocorrer problemas nos pedidos existentes.\n\n` +
          `Recomendamos marcar o stock como 0 em vez de apagar.\n\n` +
          `Tens mesmo a certeza que queres continuar?`
        );
      } else {
        return window.confirm(
          `Tens a certeza que queres apagar o produto "${item.nome}"?`
        );
      }
    
    case 'utilizadores':
      // 🚫 NÃO permitir apagar o admin principal
      if (item.email === 'authtutorial6@gmail.com') {
        alert('❌ ERRO!\n\nNão podes apagar o utilizador admin principal (authtutorial6@gmail.com)!');
        return false;
      }
      
      // ⚠️ Avisar se é admin
      if (item.tipo_utilizador === 'admin') {
        return window.confirm(
          `⚠️ CUIDADO!\n\n` +
          `"${item.nome}" é um ADMINISTRADOR!\n` +
          `Ao apagar este utilizador, o registo de administrador também será removido.\n\n` +
          `Tens a certeza que queres continuar?`
        );
      }
      
      // Verificar se tem pedidos
      const hasPedidos = data.pedidos.some(pedido => pedido.id_utilizador === item.id);
      if (hasPedidos) {
        return window.confirm(
          `⚠️ ATENÇÃO!\n\n` +
          `O utilizador "${item.nome}" tem pedidos associados.\n` +
          `Todos os pedidos, itens e pagamentos serão removidos automaticamente.\n\n` +
          `Tens a certeza que queres continuar?`
        );
      }
      
      return window.confirm(`Tens a certeza que queres apagar o utilizador "${item.nome}"?`);
    
    case 'administradores':
      // Encontrar o utilizador associado
      const utilizador = data.utilizadores.find(user => user.id === item.id_utilizador);
      
      if (utilizador && utilizador.email === 'authtutorial6@gmail.com') {
        alert('❌ ERRO!\n\nNão podes apagar o registo de administrador do utilizador principal (authtutorial6@gmail.com)');
        return false;
      }
      
      return window.confirm(
        `⚠️ ATENÇÃO!\n\n` +
        `Vais apagar o registo de administrador para "${utilizador ? utilizador.nome : 'utilizador desconhecido'}".\n` +
        `O utilizador continuará a existir, mas perderá os privilégios de admin.\n\n` +
        `Tens a certeza que queres continuar?`
      );
    
    case 'pedidos':
      // Encontrar o utilizador do pedido
      const utilizadorPedido = data.utilizadores.find(user => user.id === item.id_utilizador);
      
      // Verificar se tem itens_pedido
      const temItens = data.itenspedido.some(itemPedido => itemPedido.id_pedido === item.id);
      
      // Verificar se tem pagamentos
      const temPagamentos = data.pagamentos.some(pagamento => pagamento.id_pedido === item.id);
      
      let mensagem = `⚠️ CUIDADO!\n\n` +
        `Vais apagar o pedido #${item.id} de "${utilizadorPedido ? utilizadorPedido.nome : 'utilizador desconhecido'}".\n\n`;
      
      if (temItens || temPagamentos) {
        mensagem += `Este pedido tem:\n`;
        if (temItens) mensagem += `• Itens associados (serão removidos automaticamente)\n`;
        if (temPagamentos) mensagem += `• Pagamentos associados (serão removidos automaticamente)\n`;
        mensagem += `\n⚠️ RECOMENDAÇÃO: Em vez de apagar, considera mudar o estado para "Cancelado".\n\n`;
      }
      
      mensagem += `Tens a certeza que queres continuar?`;
      
      return window.confirm(mensagem);
    
    case 'itenspedido':
      // Encontrar o pedido e produto associados
      const pedido = data.pedidos.find(p => p.id === item.id_pedido);
      const produto = data.produtos.find(p => p.id === item.id_produto);
      
      return window.confirm(
        `⚠️ ATENÇÃO!\n\n` +
        `Vais apagar o item:\n` +
        `• Produto: ${produto ? produto.nome : 'Produto desconhecido'}\n` +
        `• Quantidade: ${item.quantidade}\n` +
        `• Do pedido #${item.id_pedido}\n\n` +
        `Esta ação não pode ser desfeita.\n\n` +
        `Tens a certeza que queres continuar?`
      );
    
    default:
      return window.confirm('Tens a certeza que queres apagar este registo?');
  }
};

const validateEdit = (endpoint, item, field, newValue) => {
  switch(endpoint) {
    case 'categorias':
      if (field === 'nome' && (!newValue || newValue.trim() === '')) {
        alert('❌ Nome da categoria não pode estar vazio!');
        return false;
      }
      break;
    
    case 'produtos':
      if (field === 'nome' && (!newValue || newValue.trim() === '')) {
        alert('❌ Nome do produto não pode estar vazio!');
        return false;
      }
      if (field === 'preco' && (isNaN(newValue) || newValue <= 0)) {
        alert('❌ Preço deve ser um número maior que 0!');
        return false;
      }
      if (field === 'stock' && (isNaN(newValue) || newValue < 0)) {
        alert('❌ Stock deve ser um número igual ou maior que 0!');
        return false;
      }
      if (field === 'categoria_id' && newValue !== '' && isNaN(newValue)) {
        alert('❌ ID da categoria deve ser um número válido ou vazio!');
        return false;
      }
      break;
    
    case 'utilizadores':
      if (field === 'nome' && (!newValue || newValue.trim() === '')) {
        alert('❌ Nome não pode estar vazio!');
        return false;
      }
      if (field === 'email') {
        // NÃO permitir mudar email do admin principal
        if (item.email === 'authtutorial6@gmail.com') {
          alert('❌ ERRO!\n\nNão podes alterar o email do administrador principal!');
          return false;
        }
        // Validar formato de email básico
        if (!newValue || !newValue.includes('@') || !newValue.includes('.')) {
          alert('❌ Email deve ter um formato válido (ex: user@email.com)!');
          return false;
        }
      }
      if (field === 'tipo_utilizador') {
        if (newValue !== 'cliente' && newValue !== 'admin') {
          alert('❌ ERRO!\n\nTipo de utilizador deve ser EXATAMENTE:\n• "cliente"\n• "admin"\n\nNão podes usar variações como "cliente1" ou "Admin"!');
          return false;
        }
      }
      if (field === 'senha' && (!newValue || newValue.trim() === '')) {
        alert('❌ Senha não pode estar vazia!');
        return false;
      }
      break;
    
    case 'administradores':
      if (field === 'id_utilizador') {
        // Verificar se o utilizador existe
        const utilizadorExiste = data.utilizadores.find(user => user.id === parseInt(newValue));
        if (!utilizadorExiste) {
          alert('❌ ERRO!\n\nO ID do utilizador não existe!');
          return false;
        }
        
        // Verificar se já é admin
        const jaEAdmin = data.administradores.find(admin => admin.id_utilizador === parseInt(newValue) && admin.id !== item.id);
        if (jaEAdmin) {
          alert('❌ ERRO!\n\nEste utilizador já é administrador!');
          return false;
        }
      }
      
      if (field === 'api_key' && (!newValue || newValue.trim() === '')) {
        alert('❌ API Key não pode estar vazia!');
        return false;
      }
      break;
    
    case 'pagamentos':
      if (field === 'estado_pagamento') {
        const estadosValidos = ['Pendente', 'Aprovado', 'Recusado', 'Cancelado'];
        if (!estadosValidos.includes(newValue)) {
          alert(`❌ Estado deve ser:\n• ${estadosValidos.join('\n• ')}`);
          return false;
        }
      }
      // Remover todas as outras validações (valor, metodo_pagamento, etc.)
      break;
    
    default:
      return true;
  }
  return true;
};

  const handleDelete = async (endpoint, id) => {
    try {
      setLoading(true);
      
      // Encontrar o item que vai ser apagado
      const itemToDelete = data[endpoint].find(item => item.id === id);
      
      // Validar se pode apagar
      if (!validateDelete(endpoint, itemToDelete)) {
        setLoading(false);
        return; // Cancelar se o utilizador não confirmar
      }
      
      // Simplesmente chamar o DELETE - CASCADE fará o resto automaticamente
      await handleCrud('DELETE', endpoint, id);
      
    } catch (error) {
      console.error('Delete error:', error);
      setError('Failed to delete: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (endpoint, item) => {
    if (!authToken) {
      alert('❌ Você precisa fazer login primeiro!');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const newData = {};
      
      if (endpoint === 'utilizadores') {
        const nome = prompt('Nome:', item.nome);
        if (nome === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'nome', nome)) {
          setLoading(false);
          return;
        }
        
        const email = prompt('Email:', item.email);
        if (email === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'email', email)) {
          setLoading(false);
          return;
        }
        
        const senha = prompt('Senha:', item.senha);
        if (senha === null) {
          setLoading(false);
          return;
        }
        
        const endereco = prompt('Endereço:', item.endereco || '');
        if (endereco === null) {
          setLoading(false);
          return;
        }
        
        const telefone = prompt('Telefone:', item.telefone || '');
        if (telefone === null) {
          setLoading(false);
          return;
        }
        
        const tipo_utilizador = prompt('Tipo (APENAS "cliente" ou "admin"):', item.tipo_utilizador);
        if (tipo_utilizador === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'tipo_utilizador', tipo_utilizador)) {
          setLoading(false);
          return;
        }
        
        // Construir newData apenas se houve mudanças
        if (nome !== item.nome) newData.nome = nome;
        if (email !== item.email) newData.email = email;
        if (senha !== item.senha) newData.senha = senha;
        if (endereco !== (item.endereco || '')) newData.endereco = endereco;
        if (telefone !== (item.telefone || '')) newData.telefone = telefone;
        if (tipo_utilizador !== item.tipo_utilizador) newData.tipo_utilizador = tipo_utilizador;
      }
      
      else if (endpoint === 'administradores') {
        const id_utilizador = prompt('ID Utilizador:', item.id_utilizador);
        if (id_utilizador === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'id_utilizador', parseInt(id_utilizador))) {
          setLoading(false);
          return;
        }
        
        const api_key = prompt('API Key:', item.api_key);
        if (api_key === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'api_key', api_key)) {
          setLoading(false);
          return;
        }
        
        // ✅ CORREÇÃO: Verificar mudanças ANTES de adicionar ao newData
        const novoIdUtilizador = parseInt(id_utilizador);
        if (novoIdUtilizador !== item.id_utilizador) {
          newData.id_utilizador = novoIdUtilizador;
        }
        if (api_key !== item.api_key) {
          newData.api_key = api_key;
        }
      }
      
      else if (endpoint === 'categorias') {
        const nome = prompt('Nome da Categoria:', item.nome);
        
        if (nome !== null && nome !== item.nome) newData.nome = nome;
      }
      
      else if (endpoint === 'produtos') {
        const nome = prompt('Nome do Produto:', item.nome);
        if (nome === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'nome', nome)) {
          setLoading(false);
          return;
        }
        
        const descricao = prompt('Descrição:', item.descricao || '');
        if (descricao === null) {
          setLoading(false);
          return;
        }
        
        const precoStr = prompt('Preço:', item.preco);
        if (precoStr === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'preco', parseFloat(precoStr))) {
          setLoading(false);
          return;
        }
        
        const stockStr = prompt('Stock:', item.stock);
        if (stockStr === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'stock', parseInt(stockStr))) {
          setLoading(false);
          return;
        }
        
        const categoria_idStr = prompt('ID Categoria (deixe vazio para NULL):', item.categoria_id || '');
        if (categoria_idStr === null) {
          setLoading(false);
          return;
        }
        if (categoria_idStr !== '' && !validateEdit(endpoint, item, 'categoria_id', parseInt(categoria_idStr))) {
          setLoading(false);
          return;
        }
        
        // ✅ CORREÇÃO: Construir newData APENAS se houve mudanças REAIS
        if (nome !== item.nome) {
          newData.nome = nome;
        }
        
        if (descricao !== (item.descricao || '')) {
          newData.descricao = descricao;
        }
        
        const novoPreco = parseFloat(precoStr);
        if (novoPreco !== item.preco) {
          newData.preco = novoPreco;
        }
        
        const novoStock = parseInt(stockStr);
        if (novoStock !== item.stock) {
          newData.stock = novoStock;
        }
        
        // ✅ CORREÇÃO PRINCIPAL: Lógica da categoria_id mais robusta
        const currentCategoriaId = item.categoria_id;
        const newCategoriaId = categoria_idStr === '' ? null : parseInt(categoria_idStr);
        
        if (currentCategoriaId !== newCategoriaId) {
          newData.categoria_id = newCategoriaId;
        }
      }
      
      else if (endpoint === 'pagamentos') {
        const estado_pagamento = prompt('Estado Pagamento (Pendente/Aprovado/Recusado/Cancelado):', item.estado_pagamento);
        if (estado_pagamento === null) {
          setLoading(false);
          return;
        }
        if (!validateEdit(endpoint, item, 'estado_pagamento', estado_pagamento)) {
          setLoading(false);
          return;
        }
        
        // Só permite alterar o estado
        if (estado_pagamento !== item.estado_pagamento) {
          newData.estado_pagamento = estado_pagamento;
        }
      }
      
      // Se não há alterações, cancela
      if (Object.keys(newData).length === 0) {
        alert('Nenhuma alteração detectada');
        return;
      }
      
      // Fazer a requisição PUT
      const response = await fetch(`${API_URL}/${endpoint}/${item.id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}` // ✅ ADICIONAR JWT
        },
        body: JSON.stringify(newData)
      });

      if (!response.ok) {
        if (response.status === 401) {
          alert('❌ Token expirado! Faça login novamente.');
          handleLogout();
          return;
        }
        if (response.status === 403) {
          alert('❌ Acesso negado! Apenas administradores podem realizar esta operação.');
          return;
        }
        const errorText = await response.text();
        throw new Error(`HTTP error! status: ${response.status}: ${errorText}`);
      }

      // Atualizar a lista COM JWT
      const getResponse = await fetch(`${API_URL}/${endpoint}`, {
        headers: {
          'Authorization': `Bearer ${authToken}` // ✅ JWT também no GET
        }
      });
      const updated = await getResponse.json();
      setData(prev => ({ ...prev, [endpoint]: updated }));

      console.log('Edit successful');
    } catch (error) {
      console.error('Edit error:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Component for displaying data
  const DataTable = ({ data, title }) => (
    <div className="data-section">
      <h2>{title}</h2>
      <CrudButtons
        onGet={() => handleCrud('GET', title.toLowerCase())}
        onPost={() => handleCrud('POST', title.toLowerCase())}
        onPut={() => handleCrud('PUT', title.toLowerCase(), data[0]?.id)}
        onDelete={() => handleCrud('DELETE', title.toLowerCase(), data[0]?.id)}
      />
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p className="error">Error: {error}</p>
      ) : (
        <table>
          <thead>
            <tr>
              {data.length > 0 && Object.keys(data[0]).map(key => (
                <th key={key}>{key}</th>
              ))}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr key={index}>
                {Object.values(item).map((value, i) => (
                  <td key={i}>{value}</td>
                ))}
                <td>
                  {title.toLowerCase() !== 'pedidos' && title.toLowerCase() !== 'itenspedido' && (
                    <button onClick={() => handleEdit(title.toLowerCase(), item)}>Edit</button>
                  )}
                  {title.toLowerCase() !== 'pagamentos' ? (
                    <button onClick={() => {
                      if (window.confirm('Are you sure you want to delete this record?')) {
                        handleDelete(title.toLowerCase(), item.id);
                      }
                    }}>Delete</button>
                  ) : (
                    <span style={{color: '#999', fontSize: '12px'}}>No Delete</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );

  // Adicione esta função antes do return
  const downloadOpenAPI = async () => {
    try {
      setLoading(true);
      
      // Buscar o arquivo OpenAPI do servidor
      const response = await fetch('/api/openapi.yaml');
      
      if (!response.ok) {
        throw new Error('Erro ao buscar OpenAPI.yaml');
      }
      
      const yamlContent = await response.text();
      
      // Criar blob e fazer download
      const blob = new Blob([yamlContent], { type: 'application/yaml' });
      const url = window.URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = 'openapi.yaml';
      document.body.appendChild(link);
      link.click();
      
      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      console.log('✅ OpenAPI.yaml downloaded successfully');
      
    } catch (error) {
      console.error('❌ Error downloading OpenAPI.yaml:', error);
      setError('Erro ao fazer download do OpenAPI.yaml: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  // ✅ NOVO: Header de autenticação
  const AuthHeader = () => (
    <div style={{ 
      padding: '20px', 
      borderBottom: '2px solid #ccc', 
      marginBottom: '20px',
      backgroundColor: '#f8f9fa'
    }}>
      {user ? (
        <div>
          <h3>👤 Bem-vindo, {user.nome}!</h3>
          <p>📧 {user.email} | 🎭 {user.tipo} {user.isAdmin && '(Admin)'}</p>
          <button 
            onClick={handleLogout} 
            style={{ 
              backgroundColor: '#dc3545', 
              color: 'white', 
              padding: '10px 20px',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            🚪 Logout
          </button>
        </div>
      ) : (
        <div>
          <h3>🔐 Login Necessário</h3>
          <p>Faça login para acessar a aplicação.</p>
          <button 
            onClick={handleGoogleLogin} 
            style={{ 
              backgroundColor: '#007bff', 
              color: 'white', 
              padding: '10px 20px',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            🔑 Login com Google
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="App">
      <AuthHeader />
      
      {user ? (
        <>
          <header className="App-header">
            <h1>🛒 Gestão de Comércio - CRUD Operations</h1>
            
            {/* Adicione este bloco de botões de utilidades */}
            <div style={{ 
              marginBottom: '20px', 
              display: 'flex', 
              gap: '10px', 
              flexWrap: 'wrap',
              justifyContent: 'center'
            }}>
              <button 
                onClick={downloadOpenAPI}
                disabled={loading}
                style={{
                  backgroundColor: '#28a745',
                  color: 'white',
                  border: 'none',
                  padding: '8px 16px',
                  borderRadius: '4px',
                  cursor: loading ? 'not-allowed' : 'pointer',
                  fontSize: '14px'
                }}
              >
                📥 Download OpenAPI.yaml
              </button>
              
              <a 
                href="https://swagger.io/docs/" 
                target="_blank" 
                rel="noopener noreferrer"
                style={{
                  backgroundColor: '#17a2b8',
                  color: 'white',
                  textDecoration: 'none',
                  padding: '8px 16px',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                📚 Swagger Docs
              </a>
            </div>

            {loading && <p>⏳ Loading...</p>}
            {error && <p style={{color: 'red'}}>❌ {error}</p>}
            
            <DataTable data={data.utilizadores} title="Utilizadores" />
            <DataTable data={data.administradores} title="Administradores" />
            <DataTable data={data.categorias} title="Categorias" />
            <DataTable data={data.produtos} title="Produtos" />
            <DataTable data={data.pedidos} title="Pedidos" />
            <DataTable data={data.itenspedido} title="ItensPedido" />
            <DataTable data={data.pagamentos} title="Pagamentos" /> 
          </header>
        </>
      ) : (
        <div style={{ textAlign: 'center', padding: '50px' }}>
          <h2>🔒 Acesso Restrito</h2>
          <p>Faça login para acessar a aplicação.</p>
        </div>
      )}
    </div>
  );
}

export default App;
