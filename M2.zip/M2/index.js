'use strict';

require('dotenv').config();
var path = require('path');
var http = require('http');
var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var oas3Tools = require('oas3-tools');
const { passport, googleStrategy, validateJWT } = require('./config/oauth');
const authRoutes = require('./routes/auth');
//const isAdmin = require('./middleware/adminAuth');
const cors = require('cors');

var serverPort = process.env.PORT || 3001;
// Create Express app
var app = express();

// Enable CORS
app.use(cors({
  origin: ['http://localhost:3000'],
  credentials: true
}));

// Cookie and session middleware
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'session_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production' }
}));

// Initialize Passport
app.use(passport.initialize());
app.use(passport.session());
passport.use(googleStrategy);

// ========== ROTAS DE AUTENTICAÇÃO (PRIMEIRO) ==========
app.use('/auth', authRoutes);

// Default route redirects to login or docs
app.get('/', (req, res) => {
  if (req.isAuthenticated()) {
    res.redirect('/docs');
  } else {
    res.redirect('/auth/login');
  }
});

// ========== MIDDLEWARE JWT PARA ROTAS API ==========
app.use('/api', (req, res, next) => {
  // ⚠️ IMPORTANTE: NÃO aplicar middleware JWT nas rotas de autenticação
  if (req.path.startsWith('/auth/')) {
    console.log(`🔓 Auth route bypassed: ${req.method} ${req.path}`);
    return next();
  }
  
  // Rotas que precisam de autenticação
  const protectedPaths = [
    '/utilizadores',
    '/administradores', 
    '/categorias',
    '/produtos',
    '/pedidos',
    '/itenspedido',
    '/pagamentos'
  ];
  
  // Verificar se é uma rota protegida
  const isProtectedPath = protectedPaths.some(path => req.path.startsWith(path));
  
  if (!isProtectedPath) {
    console.log(`🔓 Public route: ${req.method} ${req.path}`);
    return next();
  }
  
  // Verificar se é operação que modifica dados
  const isModifyingOperation = ['POST', 'PUT', 'DELETE'].includes(req.method);
  const isAdminOnlyPath = req.path.startsWith('/administradores');
  
  // Aplicar validação JWT
  validateJWT(req, res, (jwtError) => {
    if (jwtError) {
      return res.status(401).json({ error: 'Token inválido ou expirado' });
    }
    
    // Se é operação de modificação OU rota administrativa, precisa ser admin
    if (isModifyingOperation || isAdminOnlyPath) {
      // Verificar se é admin de forma mais robusta
      const isUserAdmin = req.user.isAdmin === true || req.user.tipo === 'admin';
      
      if (!isUserAdmin) {
        console.log(`❌ Access denied: ${req.user.email} (tipo: ${req.user.tipo}, isAdmin: ${req.user.isAdmin}) tried ${req.method} on ${req.path}`);
        return res.status(403).json({ 
          error: 'Acesso negado', 
          message: 'Apenas administradores podem realizar esta operação' 
        });
      }
      
      console.log(`✅ Admin access granted: ${req.user.email} (tipo: ${req.user.tipo}, isAdmin: ${req.user.isAdmin}) performing ${req.method} on ${req.path}`);
    } else {
      console.log(`✅ Read access granted: ${req.user.email} (tipo: ${req.user.tipo}) viewing ${req.path}`);
    }
    
    next();
  });
});

// ========== SWAGGER/OPENAPI CONFIGURATION ==========
var options = {
  routing: {
    controllers: path.join(__dirname, './controllers')
  },
};

var expressAppConfig = oas3Tools.expressAppConfig(path.join(__dirname, 'api/openapi.yaml'), options);
var oasApp = expressAppConfig.getApp();

// Apply the OpenAPI middleware
app.use(oasApp);

// Initialize the Swagger middleware
http.createServer(app).listen(serverPort, function () {
  console.log('🚀 Servidor rodando em http://localhost:%d', serverPort);
  console.log('🔐 Autenticação Disponível em http://localhost:%d/auth/login', serverPort);
  console.log('📚 Documentação API em http://localhost:%d/docs', serverPort);
});