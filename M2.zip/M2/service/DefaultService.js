'use strict';

// Add MySQL connection
const mysql = require('mysql2/promise');

// Create a connection pool
const pool = mysql.createPool({
  host: process.env.DATABASE_HOST || 'database',
  user: process.env.DATABASE_USER || 'dev_user',
  password: process.env.DATABASE_PASSWORD || 'dev_password',
  database: process.env.DATABASE_NAME || 'comerciodev',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

/**
 * Apagar um administrador
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.apagarAdministrador = async function(id) {
  try {
    await pool.query('DELETE FROM administrador WHERE id = ?', [id]);
    return {};
  } catch (error) {
    console.error('Error deleting admin:', error);
    throw error;
  }
}

/**
 * Apagar uma categoria
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.apagarCategoria = async function(id) {
  try {
    await pool.query('DELETE FROM categorias WHERE id = ?', [id]);
    return {};
  } catch (error) {
    console.error('Error deleting category:', error);
    throw error;
  }
}

/**
 * Apagar um pedido
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.apagarPedido = async function(id) {
  try {
    // Delete associated records from itens_pedido and pagamentos first
    await pool.query('DELETE FROM itens_pedido WHERE id_pedido = ?', [id]);
    await pool.query('DELETE FROM pagamentos WHERE id_pedido = ?', [id]);
    // Then delete the pedido
    await pool.query('DELETE FROM pedidos WHERE id = ?', [id]);
    return {};
  } catch (error) {
    console.error('Error deleting order:', error);
    throw error;
  }
}

/**
 * Apagar um produto
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.apagarProduto = async function(id) {
  try {
    await pool.query('DELETE FROM produtos WHERE id = ?', [id]);
    return {};
  } catch (error) {
    console.error('Error deleting product:', error);
    throw error;
  }
}

/**
 * Apagar um utilizador
 *
 * id Integer 
 * no response value expected for this operation
 **/
exports.apagarUtilizador = async function(id) {
  try {
    await pool.query('DELETE FROM utilizador WHERE id = ?', [id]);
    return {};
  } catch (error) {
    console.error('Error deleting user:', error);
    throw error;
  }
}

/**
 * Atualizar um administrador
 *
 * body Administrador Dados do administrador para atualização
 * id Integer 
 * returns Administrador
 **/
exports.atualizarAdministrador = async function(body, id) {
  try {
    const { id_utilizador, api_key } = body;
    await pool.query(
      'UPDATE administrador SET id_utilizador = ?, api_key = ? WHERE id = ?',
      [id_utilizador, api_key, id]
    );
    
    const [rows] = await pool.query('SELECT * FROM administrador WHERE id = ?', [id]);
    return rows[0];
  } catch (error) {
    console.error('Error updating admin:', error);
    throw error;
  }
}

/**
 * Atualizar uma categoria
 *
 * body Categoria Dados da categoria para atualização
 * id Integer 
 * returns Categoria
 **/
exports.atualizarCategoria = async function(body, id) {
  try {
    const { nome } = body;
    await pool.query(
      'UPDATE categorias SET nome = ? WHERE id = ?',
      [nome, id]
    );
    
    const [rows] = await pool.query('SELECT * FROM categorias WHERE id = ?', [id]);
    return rows[0];
  } catch (error) {
    console.error('Error updating category:', error);
    throw error;
  }
}

/**
 * Atualizar um pedido
 *
 * body Pedido Dados do pedido para atualização
 * id Integer 
 * returns Pedido
 **/
exports.atualizarPedido = async function(body, id) {
  try {
    const { id_utilizador, estado_pagamento } = body;
    await pool.query(
      'UPDATE pedidos SET id_utilizador = ?, estado_pagamento = ? WHERE id = ?',
      [id_utilizador, estado_pagamento, id]
    );
    
    const [rows] = await pool.query('SELECT * FROM pedidos WHERE id = ?', [id]);
    return rows[0];
  } catch (error) {
    console.error('Error updating order:', error);
    throw error;
  }
}

/**
 * Atualizar um produto
 *
 * body Produto Dados do produto para atualização
 * id Integer 
 * returns Produto
 **/
exports.atualizarProduto = async function(body, id) {
  try {
    const { nome, descricao, preco, stock, categoria_id } = body;
    await pool.query(
      'UPDATE produtos SET nome = ?, descricao = ?, preco = ?, stock = ?, categoria_id = ? WHERE id = ?',
      [nome, descricao, preco, stock, categoria_id, id]
    );
    
    const [rows] = await pool.query('SELECT * FROM produtos WHERE id = ?', [id]);
    return rows[0];
  } catch (error) {
    console.error('Error updating product:', error);
    throw error;
  }
}

/**
 * Atualizar um utilizador
 *
 * body Utilizador Dados do utilizador para atualização
 * id Integer 
 * returns Utilizador
 **/
exports.atualizarUtilizador = async function(body, id) {
  try {
    const { nome, email, senha, endereco, telefone, tipo_utilizador } = body;
    await pool.query(
      'UPDATE utilizador SET nome = ?, email = ?, senha = ?, endereco = ?, telefone = ?, tipo_utilizador = ? WHERE id = ?',
      [nome, email, senha, endereco, telefone, tipo_utilizador, id]
    );
    
    const [rows] = await pool.query('SELECT * FROM utilizador WHERE id = ?', [id]);
    return rows[0];
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
}

/**
 * Criar um novo administrador
 *
 * body Administrador Administrador a ser criado
 * returns Administrador
 **/
exports.criarAdministrador = async function(body) {
  try {
    const { id_utilizador, api_key } = body;
    const [result] = await pool.query(
      'INSERT INTO administrador (id_utilizador, api_key) VALUES (?, ?)',
      [id_utilizador, api_key]
    );
    
    return {
      id: result.insertId,
      id_utilizador,
      api_key
    };
  } catch (error) {
    console.error('Error creating admin:', error);
    throw error;
  }
}

/**
 * Criar uma nova categoria
 *
 * body Categoria Categoria a ser criada
 * returns Categoria
 **/
exports.criarCategoria = async function(body) {
  try {
    const { nome } = body;
    const [result] = await pool.query(
      'INSERT INTO categorias (nome) VALUES (?)',
      [nome]
    );
    
    return {
      id: result.insertId,
      nome
    };
  } catch (error) {
    console.error('Error creating category:', error);
    throw error;
  }
}

/**
 * Criar um novo pedido
 *
 * body Pedido Pedido a ser criado
 * returns Pedido
 **/
exports.criarPedido = async function(body) {
  try {
    const { id_utilizador, estado_pagamento } = body;
    const [result] = await pool.query(
      'INSERT INTO pedidos (id_utilizador, estado_pagamento) VALUES (?, ?)',
      [id_utilizador, estado_pagamento]
    );
    
    const [rows] = await pool.query('SELECT * FROM pedidos WHERE id = ?', [result.insertId]);
    return rows[0];
  } catch (error) {
    console.error('Error creating order:', error);
    throw error;
  }
}

/**
 * Criar um novo produto
 *
 * body Produto Produto a ser criado
 * returns Produto
 **/
exports.criarProduto = async function(body) {
  try {
    const { nome, descricao, preco, stock, categoria_id } = body;
    const [result] = await pool.query(
      'INSERT INTO produtos (nome, descricao, preco, stock, categoria_id) VALUES (?, ?, ?, ?, ?)',
      [nome, descricao, preco, stock, categoria_id]
    );
    
    return {
      id: result.insertId,
      nome,
      descricao,
      preco,
      stock,
      categoria_id
    };
  } catch (error) {
    console.error('Error creating product:', error);
    throw error;
  }
}

/**
 * Criar um novo utilizador
 *
 * body Utilizador Utilizador a ser criado
 * returns Utilizador
 **/
exports.criarUtilizador = async function(body) {
  try {
    const { nome, email, senha, endereco, telefone, tipo_utilizador } = body;
    const [result] = await pool.query(
      'INSERT INTO utilizador (nome, email, senha, endereco, telefone, tipo_utilizador) VALUES (?, ?, ?, ?, ?, ?)',
      [nome, email, senha, endereco, telefone, tipo_utilizador || 'cliente']
    );
    
    return {
      id: result.insertId,
      nome,
      email,
      senha,
      endereco,
      telefone,
      tipo_utilizador: tipo_utilizador || 'cliente'
    };
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
}

/**
 * Listar todos os administradores
 *
 * returns List
 **/
exports.listarAdministradores = async function() {
  try {
    const [rows] = await pool.query('SELECT * FROM administrador');
    return rows;
  } catch (error) {
    console.error('Error listing admins:', error);
    throw error;
  }
}

/**
 * Listar todas as categorias
 *
 * returns List
 **/
exports.listarCategorias = async function() {
  try {
    const [rows] = await pool.query('SELECT * FROM categorias');
    return rows;
  } catch (error) {
    console.error('Error listing categories:', error);
    throw error;
  }
}

/**
 * Listar todos os pedidos
 *
 * returns List
 **/
exports.listarPedidos = async function() {
  try {
    const [rows] = await pool.query('SELECT * FROM pedidos');
    return rows;
  } catch (error) {
    console.error('Error listing orders:', error);
    throw error;
  }
}

/**
 * Listar todos os produtos
 *
 * returns List
 **/
exports.listarProdutos = async function() {
  try {
    const [rows] = await pool.query('SELECT * FROM produtos');
    return rows;
  } catch (error) {
    console.error('Error listing products:', error);
    throw error;
  }
}

/**
 * Listar todos os utilizadores
 *
 * returns List
 **/
exports.listarUtilizadores = async function() {
  try {
    const [rows] = await pool.query('SELECT * FROM utilizador');
    return rows;
  } catch (error) {
    console.error('Error listing users:', error);
    throw error;
  }
}

/**
 * Obter um administrador por ID
 *
 * id Integer 
 * returns Administrador
 **/
exports.obterAdministrador = async function(id) {
  try {
    const [rows] = await pool.query('SELECT * FROM administrador WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error('Error getting admin:', error);
    throw error;
  }
}

/**
 * Obter uma categoria por ID
 *
 * id Integer 
 * returns Categoria
 **/
exports.obterCategoria = async function(id) {
  try {
    const [rows] = await pool.query('SELECT * FROM categorias WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error('Error getting category:', error);
    throw error;
  }
}

/**
 * Obter um pedido por ID
 *
 * id Integer 
 * returns Pedido
 **/
exports.obterPedido = async function(id) {
  try {
    const [rows] = await pool.query('SELECT * FROM pedidos WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error('Error getting order:', error);
    throw error;
  }
}

/**
 * Obter um produto por ID
 *
 * id Integer 
 * returns Produto
 **/
exports.obterProduto = async function(id) {
  try {
    const [rows] = await pool.query('SELECT * FROM produtos WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error('Error getting product:', error);
    throw error;
  }
}

/**
 * Obter um utilizador por ID
 *
 * id Integer 
 * returns Utilizador
 **/
exports.obterUtilizador = async function(id) {
  try {
    const [rows] = await pool.query('SELECT * FROM utilizador WHERE id = ?', [id]);
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error('Error getting user:', error);
    throw error;
  }
}

/**
 * Listar todos os itens de pedido
 * returns List
 **/
exports.listarItensPedido = async function() {
  try {
    console.log('📋 Listing all itens pedido');
    
    // ✅ CORREÇÃO: Usar nomes corretos das tabelas (plurais)
    const [rows] = await pool.query(`
      SELECT 
        ip.*,
        p.nome as produto_nome,
        p.preco as produto_preco,
        ped.data_pedido,
        u.nome as cliente_nome
      FROM itens_pedido ip
      LEFT JOIN produtos p ON ip.id_produto = p.id
      LEFT JOIN pedidos ped ON ip.id_pedido = ped.id
      LEFT JOIN utilizador u ON ped.id_utilizador = u.id
      ORDER BY ip.id DESC
    `);
    
    console.log(`✅ Found ${rows.length} itens pedido`);
    return rows;
  } catch (error) {
    console.error('❌ Error listing itens pedido:', error);
    throw error;
  }
};

/**
 * Criar um novo item de pedido
 * body ItemPedido Item de pedido a ser criado
 * returns ItemPedido
 **/
exports.criarItemPedido = async function(body) {
  try {
    console.log('➕ Creating new item pedido:', body);
    
    const { id_pedido, id_produto, quantidade, preco_unitario } = body;
    const [result] = await pool.query(
      'INSERT INTO itens_pedido (id_pedido, id_produto, quantidade, preco_unitario) VALUES (?, ?, ?, ?)',
      [id_pedido, id_produto, quantidade, preco_unitario]
    );
    
    // ✅ CORREÇÃO: Usar 'produtos' (plural)
    const [newItem] = await pool.query(
      `SELECT 
        ip.*,
        p.nome as produto_nome
      FROM itens_pedido ip
      LEFT JOIN produtos p ON ip.id_produto = p.id
      WHERE ip.id = ?`,
      [result.insertId]
    );
    
    console.log(`✅ Item pedido created with ID: ${result.insertId}`);
    return newItem[0];
  } catch (error) {
    console.error('❌ Error creating item pedido:', error);
    throw error;
  }
};

/**
 * Obter um item de pedido por ID
 * id Integer 
 * returns ItemPedido
 **/
exports.obterItemPedido = async function(id) {
  try {
    console.log(`🔍 Getting item pedido: ${id}`);
    
    // ✅ CORREÇÃO: Usar nomes corretos das tabelas
    const [rows] = await pool.query(
      `SELECT 
        ip.*,
        p.nome as produto_nome,
        ped.data_pedido
      FROM itens_pedido ip
      LEFT JOIN produtos p ON ip.id_produto = p.id
      LEFT JOIN pedidos ped ON ip.id_pedido = ped.id
      WHERE ip.id = ?`,
      [id]
    );
    
    console.log(`✅ Item pedido found: ${rows.length > 0 ? rows[0].id : 'none'}`);
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error('❌ Error getting item pedido:', error);
    throw error;
  }
};

/**
 * Atualizar um item de pedido
 * body ItemPedido Dados do item de pedido para atualização
 * id Integer 
 * returns ItemPedido
 **/
exports.atualizarItemPedido = async function(body, id) {
  try {
    console.log(`🔄 Updating item pedido ${id}:`, body);
    
    // Verificar se existe
    const [existing] = await pool.query('SELECT * FROM itens_pedido WHERE id = ?', [id]);
    
    if (existing.length === 0) {
      return null;
    }
    
    const current = existing[0];
    const { quantidade, preco_unitario } = body;
    
    await pool.query(
      'UPDATE itens_pedido SET quantidade = ?, preco_unitario = ? WHERE id = ?',
      [
        quantidade || current.quantidade,
        preco_unitario || current.preco_unitario,
        id
      ]
    );
    
    // ✅ CORREÇÃO: Usar 'produtos' (plural)
    const [updated] = await pool.query(
      `SELECT 
        ip.*,
        p.nome as produto_nome
      FROM itens_pedido ip
      LEFT JOIN produtos p ON ip.id_produto = p.id
      WHERE ip.id = ?`,
      [id]
    );
    
    console.log(`✅ Item pedido updated: ${id}`);
    return updated[0];
  } catch (error) {
    console.error('❌ Error updating item pedido:', error);
    throw error;
  }
};

/**
 * Apagar um item de pedido
 * id Integer 
 * no response value expected for this operation
 **/
exports.apagarItemPedido = async function(id) {
  try {
    console.log(`🗑️ Deleting item pedido: ${id}`);
    
    await pool.query('DELETE FROM itens_pedido WHERE id = ?', [id]);
    
    console.log(`✅ Item pedido deleted: ${id}`);
    return {};
  } catch (error) {
    console.error('❌ Error deleting item pedido:', error);
    throw error;
  }
};

/**
 * Listar todos os pagamentos
 * returns List
 **/
exports.listarPagamentos = async function() {
  try {
    console.log('💳 Listing all pagamentos');
    
    const [rows] = await pool.query(`
      SELECT 
        pag.*,
        ped.data_pedido as pedido_data,
        u.nome as cliente_nome
      FROM pagamentos pag
      LEFT JOIN pedidos ped ON pag.id_pedido = ped.id
      LEFT JOIN utilizador u ON ped.id_utilizador = u.id
      ORDER BY pag.id DESC
    `);
    
    console.log(`✅ Found ${rows.length} pagamentos`);
    return rows;
  } catch (error) {
    console.error('❌ Error listing pagamentos:', error);
    throw error;
  }
};

/**
 * Criar um novo pagamento
 **/
exports.criarPagamento = async function(body) {
  try {
    console.log('💳 Creating new pagamento:', body);
    
    const { id_pedido, valor, metodo_pagamento, status } = body;
    const [result] = await pool.query(
      'INSERT INTO pagamentos (id_pedido, valor, metodo_pagamento, data_pagamento, status) VALUES (?, ?, ?, NOW(), ?)',
      [id_pedido, valor, metodo_pagamento, status || 'Pendente']
    );
    
    const [newPagamento] = await pool.query(
      `SELECT 
        pag.*,
        ped.data_pedido as pedido_data,
        u.nome as cliente_nome
      FROM pagamentos pag
      LEFT JOIN pedidos ped ON pag.id_pedido = ped.id
      LEFT JOIN utilizador u ON ped.id_utilizador = u.id
      WHERE pag.id = ?`,
      [result.insertId]
    );
    
    console.log(`✅ Pagamento created with ID: ${result.insertId}`);
    return newPagamento[0];
  } catch (error) {
    console.error('❌ Error creating pagamento:', error);
    throw error;
  }
};

/**
 * Obter um pagamento por ID
 **/
exports.obterPagamento = async function(id) {
  try {
    console.log(`💳 Getting pagamento: ${id}`);
    
    const [rows] = await pool.query(
      `SELECT 
        pag.*,
        ped.data_pedido as pedido_data,
        u.nome as cliente_nome
      FROM pagamentos pag
      LEFT JOIN pedidos ped ON pag.id_pedido = ped.id
      LEFT JOIN utilizador u ON ped.id_utilizador = u.id
      WHERE pag.id = ?`,
      [id]
    );
    
    console.log(`✅ Pagamento found: ${rows.length > 0 ? rows[0].id : 'none'}`);
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error('❌ Error getting pagamento:', error);
    throw error;
  }
};

/**
 * Atualizar um pagamento
 **/
exports.atualizarPagamento = async function(body, id) {
  try {
    console.log(`💳 Updating pagamento ${id}:`, body);
    
    const [existing] = await pool.query('SELECT * FROM pagamentos WHERE id = ?', [id]);
    
    if (existing.length === 0) {
      return null;
    }
    
    const current = existing[0];
    const { valor, metodo_pagamento, status } = body;
    
    await pool.query(
      'UPDATE pagamentos SET valor = ?, metodo_pagamento = ?, status = ? WHERE id = ?',
      [
        valor || current.valor,
        metodo_pagamento || current.metodo_pagamento,
        status || current.status,
        id
      ]
    );
    
    const [updated] = await pool.query(
      `SELECT 
        pag.*,
        ped.data_pedido as pedido_data,
        u.nome as cliente_nome
      FROM pagamentos pag
      LEFT JOIN pedidos ped ON pag.id_pedido = ped.id
      LEFT JOIN utilizador u ON ped.id_utilizador = u.id
      WHERE pag.id = ?`,
      [id]
    );
    
    console.log(`✅ Pagamento updated: ${id}`);
    return updated[0];
  } catch (error) {
    console.error('❌ Error updating pagamento:', error);
    throw error;
  }
};

/**
 * Apagar um pagamento
 **/
exports.apagarPagamento = async function(id) {
  try {
    console.log(`💳 Deleting pagamento: ${id}`);
    
    await pool.query('DELETE FROM pagamentos WHERE id = ?', [id]);
    
    console.log(`✅ Pagamento deleted: ${id}`);
    return {};
  } catch (error) {
    console.error('❌ Error deleting pagamento:', error);
    throw error;
  }
};